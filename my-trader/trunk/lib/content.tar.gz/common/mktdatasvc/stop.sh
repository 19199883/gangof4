#!/bin/bash
pkill -9  allexlv1_mktsvc 
