/////////////////////////////////////////////////////////////////////////
///@company 南京艾科朗克信息科技有限公司
///@file CXeleFtdcUserApiStruct.h
///@brief 业务数据结构
/////////////////////////////////////////////////////////////////////////
 
#ifndef _XELE_FTDCSTRUCT_H

#define _XELE_FTDCSTRUCT_H

#include "CXeleFtdcUserApiDataType.h"

#pragma pack(push,1)

///信息分发


struct CXeleFtdcDisseminationField
{
	///序列系列号
	TXeleFtdcSequenceSeriesType	SequenceSeries;
	///序列号
	TXeleFtdcSequenceNoType	SequenceNo;
};

///响应信息
struct CXeleFtdcRspInfoField
{
	///错误代码
	TXeleFtdcErrorIDType	ErrorID;
	///错误信息
	TXeleFtdcErrorMsgType	ErrorMsg;
};

///用户登录请求
struct CXeleFtdcReqUserLoginField
{
	///交易日
	TXeleFtdcDateType	TradingDay;
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///密码
	TXeleFtdcPasswordType	Password;
	///用户端产品信息
	TXeleFtdcProductInfoType	UserProductInfo;
	///接口端产品信息
	TXeleFtdcProductInfoType	InterfaceProductInfo;
	///协议信息
	TXeleFtdcProtocolInfoType	ProtocolInfo;
	///数据中心代码
	TXeleFtdcDataCenterIDType	DataCenterID;
};

///用户登录应答
struct CXeleFtdcRspUserLoginField
{
	///交易日
	TXeleFtdcDateType	TradingDay;
	///登录成功时间
	TXeleFtdcTimeType	LoginTime;
	///最大本地报单号
	TXeleFtdcOrderLocalIDType	MaxOrderLocalID;
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///交易系统名称
	TXeleFtdcTradingSystemNameType	TradingSystemName;
	///数据中心代码
	TXeleFtdcDataCenterIDType	DataCenterID;
	///会员私有流当前长度
	TXeleFtdcSequenceNoType	PrivateFlowSize;
	///交易员私有流当前长度
	TXeleFtdcSequenceNoType	UserFlowSize;
};

///用户登出请求
struct CXeleFtdcReqUserLogoutField
{
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
};

///用户登出应答
struct CXeleFtdcRspUserLogoutField
{
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
};

///输入报单
struct CXeleFtdcInputOrderField
{
	///报单编号
	TXeleFtdcOrderSysIDType	OrderSysID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///客户代码
	TXeleFtdcClientIDType	ClientID;
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///报单价格条件
	TXeleFtdcOrderPriceTypeType	OrderPriceType;
	///买卖方向
	TXeleFtdcDirectionType	Direction;
	///组合开平标志
	TXeleFtdcCombOffsetFlagType	CombOffsetFlag;
	///组合投机套保标志
	TXeleFtdcCombHedgeFlagType	CombHedgeFlag;
	///价格
	TXeleFtdcPriceType	LimitPrice;
	///数量
	TXeleFtdcVolumeType	VolumeTotalOriginal;
	///有效期类型
	TXeleFtdcTimeConditionType	TimeCondition;
	///GTD日期
	TXeleFtdcDateType	GTDDate;
	///成交量类型
	TXeleFtdcVolumeConditionType	VolumeCondition;
	///最小成交量
	TXeleFtdcVolumeType	MinVolume;
	///触发条件
	TXeleFtdcContingentConditionType	ContingentCondition;
	///止损价
	TXeleFtdcPriceType	StopPrice;
	///强平原因
	TXeleFtdcForceCloseReasonType	ForceCloseReason;
	///本地报单编号
	TXeleFtdcOrderLocalIDType	OrderLocalID;
	///自动挂起标志
	TXeleFtdcBoolType	IsAutoSuspend;
	///业务单元
	TXeleFtdcOrderLocalIDType   ExchangeOrderSysID;
	char 	                    _unused_1[8];
};

///报单操作
struct CXeleFtdcOrderActionField
{
	///报单编号
	TXeleFtdcOrderSysIDType	OrderSysID;
	///本地报单编号
	TXeleFtdcOrderLocalIDType	OrderLocalID;
	///报单操作标志
	TXeleFtdcActionFlagType	ActionFlag;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///客户代码
	TXeleFtdcClientIDType	ClientID;
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///价格
	TXeleFtdcPriceType	LimitPrice;
	///数量变化
	TXeleFtdcVolumeType	VolumeChange;
	///操作本地编号
	TXeleFtdcOrderLocalIDType	ActionLocalID;
	///业务单元
	TXeleFtdcBusinessUnitType	BusinessUnit;
};



///用户口令修改
struct CXeleFtdcUserPasswordUpdateField
{
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///旧密码
	TXeleFtdcPasswordType	OldPassword;
	///新密码
	TXeleFtdcPasswordType	NewPassword;
};


///报单查询
struct CXeleFtdcQryOrderField
{
    ///交易用户代码
    TXeleFtdcUserIDType UserID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///报单编号
	TXeleFtdcOrderSysIDType	OrderSysID;
	///开始时间
	TXeleFtdcTimeType	TimeStart;
	///结束时间
	TXeleFtdcTimeType	TimeEnd;
};

///成交查询
struct CXeleFtdcQryTradeField
{
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///成交编号
	TXeleFtdcTradeIDType	TradeID;
	///开始时间
	TXeleFtdcTimeType	TimeStart;
	///结束时间
	TXeleFtdcTimeType	TimeEnd;
};

///行情查询
struct CXeleFtdcQryMarketDataField
{
	///产品代码
	TXeleFtdcProductIDType	ProductID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
};


///客户持仓查询
struct CXeleFtdcQryClientPositionField
{
    ///客户代码
    TXeleFtdcClientIDType       ClientID;
    ///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///客户类型
	TXeleFtdcClientTypeType     ClientType;
};

///合约查询
struct CXeleFtdcQryInstrumentField
{
    ///产品代码
	TXeleFtdcProductIDType      ProductID;
	///合约代码
	TXeleFtdcInstrumentIDType   InstrumentID;
};

///客户持仓
struct CXeleFtdcRspClientPositionField
{
	///交易日
	TXeleFtdcDateType	TradingDay;
	///结算组代码
	TXeleFtdcSettlementGroupIDType	SettlementGroupID;
	///结算编号
	TXeleFtdcSettlementIDType	SettlementID;
	///投机套保标志
	TXeleFtdcHedgeFlagType	HedgeFlag;
	///持仓多空方向
	TXeleFtdcPosiDirectionType	PosiDirection;
	///上日持仓
	TXeleFtdcVolumeType	YdPosition;
	///今日持仓
	TXeleFtdcVolumeType	Position;
	///多头冻结
	TXeleFtdcVolumeType	LongFrozen;
	///空头冻结
	TXeleFtdcVolumeType	ShortFrozen;
	///昨日多头冻结
	TXeleFtdcVolumeType	YdLongFrozen;
	///昨日空头冻结
	TXeleFtdcVolumeType	YdShortFrozen;
	///当日买成交量
	TXeleFtdcVolumeType	BuyTradeVolume;
	///当日卖成交量
	TXeleFtdcVolumeType	SellTradeVolume;
	///持仓成本
	TXeleFtdcMoneyType	PositionCost;
	///昨日持仓成本
	TXeleFtdcMoneyType	YdPositionCost;
	///占用的保证金
	TXeleFtdcMoneyType	UseMargin;
	///冻结的保证金
	TXeleFtdcMoneyType	FrozenMargin;
	///多头冻结的保证金
	TXeleFtdcMoneyType	LongFrozenMargin;
	///空头冻结的保证金
	TXeleFtdcMoneyType	ShortFrozenMargin;
	///冻结的权利金
	TXeleFtdcMoneyType	FrozenPremium;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///客户代码
	TXeleFtdcClientIDType	ClientID;
};

///合约

struct CXeleFtdcRspInstrumentField
{
	///结算组代码
	TXeleFtdcSettlementGroupIDType	SettlementGroupID;
	///产品代码
	TXeleFtdcProductIDType	ProductID;
	///产品组代码
	TXeleFtdcProductGroupIDType	ProductGroupID;
	///基础商品代码
	TXeleFtdcInstrumentIDType	UnderlyingInstrID;
	///产品类型
	TXeleFtdcProductClassType	ProductClass;
	///持仓类型
	TXeleFtdcPositionTypeType	PositionType;
	///执行价
	TXeleFtdcPriceType	StrikePrice;
	///期权类型
	TXeleFtdcOptionsTypeType	OptionsType;
	///合约数量乘数
	TXeleFtdcVolumeMultipleType	VolumeMultiple;
	///合约基础商品乘数
	TXeleFtdcUnderlyingMultipleType	UnderlyingMultiple;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///合约名称
	TXeleFtdcInstrumentNameType	InstrumentName;
	///交割年份
	TXeleFtdcYearType	DeliveryYear;
	///交割月
	TXeleFtdcMonthType	DeliveryMonth;
	///提前月份
	TXeleFtdcAdvanceMonthType	AdvanceMonth;
	///当前是否交易
	TXeleFtdcBoolType	IsTrading;
	///创建日
	TXeleFtdcDateType	CreateDate;
	///上市日
	TXeleFtdcDateType	OpenDate;
	///到期日
	TXeleFtdcDateType	ExpireDate;
	///开始交割日
	TXeleFtdcDateType	StartDelivDate;
	///最后交割日
	TXeleFtdcDateType	EndDelivDate;
	///挂牌基准价
	TXeleFtdcPriceType	BasisPrice;
	///市价单最大下单量
	TXeleFtdcVolumeType	MaxMarketOrderVolume;
	///市价单最小下单量
	TXeleFtdcVolumeType	MinMarketOrderVolume;
	///限价单最大下单量
	TXeleFtdcVolumeType	MaxLimitOrderVolume;
	///限价单最小下单量
	TXeleFtdcVolumeType	MinLimitOrderVolume;
	///最小变动价位
	TXeleFtdcPriceType	PriceTick;
	///交割月自然人开仓
	TXeleFtdcMonthCountType	AllowDelivPersonOpen;
};

///Ffex合约
struct CXeleFtdcInstrumentField
{
    ///结算组代码
    TXeleFtdcSettlementGroupIDType  SettlementGroupID;
    ///产品代码
    TXeleFtdcProductIDType  ProductID;
    ///产品组代码
    TXeleFtdcProductGroupIDType ProductGroupID;
    ///基础商品代码
    TXeleFtdcInstrumentIDType   UnderlyingInstrID;
    ///产品类型
    TXeleFtdcProductClassType   ProductClass;
    ///持仓类型
    TXeleFtdcPositionTypeType   PositionType;
    ///执行价
    TXeleFtdcPriceType  StrikePrice;
    ///期权类型
    TXeleFtdcOptionsTypeType    OptionsType;
    ///合约数量乘数
    TXeleFtdcVolumeMultipleType VolumeMultiple;
    ///合约基础商品乘数
    TXeleFtdcUnderlyingMultipleType UnderlyingMultiple;
    ///合约代码
    TXeleFtdcInstrumentIDType   InstrumentID;
    ///合约名称
    TXeleFtdcInstrumentNameType InstrumentName;
    ///交割年份
    TXeleFtdcYearType   DeliveryYear;
    ///交割月
    TXeleFtdcMonthType  DeliveryMonth;
    ///提前月份
    TXeleFtdcAdvanceMonthType   AdvanceMonth;
    ///当前是否交易
    TXeleFtdcBoolType   IsTrading;
};


///成交
struct CXeleFtdcTradeField
{
	///交易日
	TXeleFtdcDateType	TradingDay;
	///结算组代码
	TXeleFtdcSettlementGroupIDType	SettlementGroupID;
	///结算编号
	TXeleFtdcSettlementIDType	SettlementID;
	///成交编号
	TXeleFtdcTradeIDType	TradeID;
	///买卖方向
	TXeleFtdcDirectionType	Direction;
	///报单编号
	TXeleFtdcOrderSysIDType	OrderSysID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///客户代码
	TXeleFtdcClientIDType	ClientID;
	///交易角色
	TXeleFtdcTradingRoleType	TradingRole;
	///资金帐号
	TXeleFtdcAccountIDType	AccountID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///开平标志
	TXeleFtdcOffsetFlagType	OffsetFlag;
	///投机套保标志
	TXeleFtdcHedgeFlagType	HedgeFlag;
	///价格
	TXeleFtdcPriceType	Price;
	///数量
	TXeleFtdcVolumeType	Volume;
	///成交时间
	TXeleFtdcTimeType	TradeTime;
	///成交类型
	TXeleFtdcTradeTypeType	TradeType;
	///成交价来源
	TXeleFtdcPriceSourceType	PriceSource;
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///本地报单编号
	TXeleFtdcOrderLocalIDType	OrderLocalID;
	///结算会员编号
	TXeleFtdcParticipantIDType	ClearingPartID;
	///业务单元
	TXeleFtdcBusinessUnitType	BusinessUnit;
};

///报单
struct CXeleFtdcOrderField
{
	///交易日
	TXeleFtdcDateType	TradingDay;
	///结算组代码
	TXeleFtdcSettlementGroupIDType	SettlementGroupID;
	///结算编号
	TXeleFtdcSettlementIDType	SettlementID;
	///报单编号
	TXeleFtdcOrderSysIDType	OrderSysID;
	///会员代码
	TXeleFtdcParticipantIDType	ParticipantID;
	///客户代码
	TXeleFtdcClientIDType	ClientID;
	///交易用户代码
	TXeleFtdcUserIDType	UserID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///报单价格条件
	TXeleFtdcOrderPriceTypeType	OrderPriceType;
	///买卖方向
	TXeleFtdcDirectionType	Direction;
	///组合开平标志
	TXeleFtdcCombOffsetFlagType	CombOffsetFlag;
	///组合投机套保标志
	TXeleFtdcCombHedgeFlagType	CombHedgeFlag;
	///价格
	TXeleFtdcPriceType	LimitPrice;
	///数量
	TXeleFtdcVolumeType	VolumeTotalOriginal;
	///有效期类型
	TXeleFtdcTimeConditionType	TimeCondition;
	///GTD日期
	TXeleFtdcDateType	GTDDate;
	///成交量类型
	TXeleFtdcVolumeConditionType	VolumeCondition;
	///最小成交量
	TXeleFtdcVolumeType	MinVolume;
	///触发条件
	TXeleFtdcContingentConditionType	ContingentCondition;
	///止损价
	TXeleFtdcPriceType	StopPrice;
	///强平原因
	TXeleFtdcForceCloseReasonType	ForceCloseReason;
	///本地报单编号
	TXeleFtdcOrderLocalIDType	OrderLocalID;
	///自动挂起标志
	TXeleFtdcBoolType	IsAutoSuspend;
	///报单来源
	TXeleFtdcOrderSourceType	OrderSource;
	///报单状态
	TXeleFtdcOrderStatusType	OrderStatus;
	///报单类型
	TXeleFtdcOrderTypeType	OrderType;
	///今成交数量
	TXeleFtdcVolumeType	VolumeTraded;
	///剩余数量
	TXeleFtdcVolumeType	VolumeTotal;
	///报单日期
	TXeleFtdcDateType	InsertDate;
	///插入时间
	TXeleFtdcTimeType	InsertTime;
	///激活时间
	TXeleFtdcTimeType	ActiveTime;
	///挂起时间
	TXeleFtdcTimeType	SuspendTime;
	///最后修改时间
	TXeleFtdcTimeType	UpdateTime;
	///撤销时间
	TXeleFtdcTimeType	CancelTime;
	///最后修改交易用户代码
	TXeleFtdcUserIDType	ActiveUserID;
	///优先权
	TXeleFtdcPriorityType	Priority;
	///按时间排队的序号
	TXeleFtdcTimeSortIDType	TimeSortID;
	///结算会员编号
	TXeleFtdcParticipantIDType	ClearingPartID;
	///业务单元
	TXeleFtdcBusinessUnitType	BusinessUnit;
};

///合约状态
struct CXeleFtdcInstrumentStatusField
{
	///结算组代码
	TXeleFtdcSettlementGroupIDType	SettlementGroupID;
	///合约代码
	TXeleFtdcInstrumentIDType	InstrumentID;
	///合约交易状态
	TXeleFtdcInstrumentStatusType	InstrumentStatus;
	///交易阶段编号
	TXeleFtdcTradingSegmentSNType	TradingSegmentSN;
	///进入本状态时间
	TXeleFtdcTimeType	EnterTime;
	///进入本状态原因
	TXeleFtdcInstStatusEnterReasonType	EnterReason;
};

///客户资金查询
struct CXeleFtdcQryClientAccountField
{
    ///客户代码
    TXeleFtdcClientIDType  ClientID;
    ///资金帐号
    TXeleFtdcAccountIDType AccountID;
};

///客户资金
struct CXeleFtdcRspClientAccountField
{
    ///交易日
    TXeleFtdcDateType               TradingDay;
    ///结算组代码
    TXeleFtdcSettlementGroupIDType  SettlementGroupID;
    ///结算编号
    TXeleFtdcSettlementIDType       SettlementID;
    ///上次结算准备金
    TXeleFtdcMoneyType              PreBalance;
    ///当前保证金总额
    TXeleFtdcMoneyType              CurrMargin;
    ///平仓盈亏
    TXeleFtdcMoneyType              CloseProfit;
    ///期权权利金收支
    TXeleFtdcMoneyType              Premium;
    ///入金金额
    TXeleFtdcMoneyType              Deposit;
    ///出金金额
    TXeleFtdcMoneyType              Withdraw;
    ///期货结算准备金
    TXeleFtdcMoneyType              Balance;
    ///可提资金
    TXeleFtdcMoneyType              Available;
    ///资金帐号
    TXeleFtdcAccountIDType          AccountID;
    ///冻结的保证金
    TXeleFtdcMoneyType              FrozenMargin;
    ///冻结的权利金
    TXeleFtdcMoneyType              FrozenPremium;
    ///基本准备金
    TXeleFtdcMoneyType              BaseReserve;
    ///浮动盈亏
    TXeleFtdcMoneyType              floatProfitAndLoss;
};

struct CXeleFtdcQryInstrumentMarginRateField
{
    ///合约代码
    TXeleFtdcInstrumentIDType       InstrumentID;
    ///客户代码
    TXeleFtdcClientIDType           ClientID;
    ///投机套保标志
    TXeleFtdcHedgeFlagType          HedgeFlag;
};

struct CXeleFtdcRspInstrumentMarginRateField
{
    ///合约代码
    TXeleFtdcInstrumentIDType    InstrumentID;
    ///客户代码
    TXeleFtdcClientIDType        ClientID;
    ///投机套保标志
    TXeleFtdcHedgeFlagType       HedgeFlag;
    ///多头保证金率
    TXeleFtdcRatioType           LongMarginRatioByMoney;
    ///多头保证金费
    TXeleFtdcRatioType           LongMarginRatioByVolume;
    ///空头保证金率
    TXeleFtdcRatioType           ShortMarginRatioByMoney;
    ///空头保证金费
    TXeleFtdcRatioType           ShortMarginRatioByVolume;
    ///是否相对交易所收取
    TXeleFtdcBoolType            IsRelative;
};

struct CXeleFtdcQryInstrumentCommissionRateField
{
    ///合约代码
    TXeleFtdcInstrumentIDType       InstrumentID;
    ///客户代码
    TXeleFtdcClientIDType           ClientID;
};

struct CXeleFtdcRspInstrumentCommissionRateField
{
    ///合约代码
    TXeleFtdcInstrumentIDType    InstrumentID;
    ///客户代码
    TXeleFtdcClientIDType        ClientID;
    ///开仓手续费率
    TXeleFtdcRatioType           OpenRatioByMoney;
    ///开仓手续费
    TXeleFtdcRatioType           OpenRatioByVolume;
    ///平仓手续费率
    TXeleFtdcRatioType           CloseRatioByMoney;
    ///平仓手续费
    TXeleFtdcRatioType           CloseRatioByVolume;
    ///平今手续费率
    TXeleFtdcRatioType           CloseTodayRatioByMoney;
    ///平今手续费
    TXeleFtdcRatioType           CloseTodayRatioByVolume;
};

///合约状态查询
struct CXeleFtdcQryInstrumentStatusField
{
    ///起始合约代码
    TXeleFtdcInstrumentIDType   InstIDStart;
    ///结束合约代码
    TXeleFtdcInstrumentIDType   InstIDEnd;
};

#pragma pack(pop)

#endif
