#include "qtm.h"

void
set_criteria(const criteria_t *data)
{
}

void
acquire_quote_time_field(const char *name, const char *time_str){}

 void
update_state(const char *name, int type, int status, const char *description){}

void
update_compliance(const char *name, int type, int status, const char *description){}

void
qtm_finish(){}
