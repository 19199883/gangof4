/*
 * share_mem.h
 */

#ifndef _SHARE_MEM_H_
#define _SHARE_MEM_H_


#pragma pack(push)
#pragma pack(8)

#ifdef __cplusplus
extern "C"
{
#endif


extern void write_share_mem(char *mem, void *ords);
extern void * env_init(int share_memory_key);
extern void env_fini(void * shm_addr);


#ifdef __cplusplus
}
#endif


#pragma pack(pop)


#endif

