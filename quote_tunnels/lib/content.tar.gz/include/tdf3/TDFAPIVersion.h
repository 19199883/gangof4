#ifndef __WIND_TDF_API_VERSION_H__
#define __WIND_TDF_API_VERSION_H__

#ifdef __cplusplus
extern "C" {
#endif

static const char* TDF_Version()
{
    return "TDFAPI3.1.2";
}
#ifdef __cplusplus
}
#endif

#endif